/// End a code block started by "ignore-deprecated-pre.hxx".
#if defined(__GNUC__)

#pragma GCC diagnostic pop

#endif // __GNUC__
